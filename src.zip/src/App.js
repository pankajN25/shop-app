import './App.css';
import ShopRouter from './component/router/ShopRouter';

function App() {
  return (
    <div className="App">
      <header>Welcome to React Router</header>
      <ShopRouter />
    </div>
  );
}

export default App;
