import { Link, Outlet } from "react-router-dom";

const ShopNavBar = () => {
  return (
    <div>
      <nav className="bg-light p-3 shadow d-flex justify-content-between">
        <ul className="d-flex gap-4 list-unstyled mb-0">
          <li>
            <Link className="text-dark text-decoration-none fw-bold" to="/">
              Home
            </Link>
          </li>
          <li>
            <Link className="text-dark text-decoration-none fw-bold" to="elec">
              Electronic
            </Link>
          </li>
          <li>
            <Link className="text-dark text-decoration-none fw-bold" to="cloths">
              Clothing
            </Link>
          </li>
        </ul>
        <ul className="navbar-nav">
          <li className='nav-item'>
            <Link className="nav-link text-dark text-decoration-none fw-bold" to="login_register">
              Login/Register
            </Link>
          </li>
        </ul>
      </nav>
      <Outlet />
    </div>
  );
};

export default ShopNavBar;