const PageNotFound = () => {
    return (
      <div>
        <h1>Error404 Page Not Found</h1>
      </div>
    );
  };
  
  export default PageNotFound;