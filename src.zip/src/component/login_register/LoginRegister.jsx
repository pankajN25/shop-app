import SignIn from "./SignIn"

const LoginRegister = ()=>{
     return <div>
      
        <SignIn/>
     </div>
}
export default LoginRegister