import { Outlet } from "react-router-dom";
const Laptop = ()=>{
    return(
        <>
        <Outlet/>
        </>
    )
    
}
export default Laptop;