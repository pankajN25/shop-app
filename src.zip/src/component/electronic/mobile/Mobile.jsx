import { Outlet } from "react-router-dom";

const Mobile = () => {
    return (
        <>
           
            <Outlet />
        </>
    );
};

export default Mobile;
