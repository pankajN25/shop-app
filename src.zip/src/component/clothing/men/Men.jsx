const Men=()=>{
    return(
        <h2>men Section</h2>
    )
}
export default Men;