const Ladies=()=>{
    return (
        <h2>ladies section</h2>
    )
}
export default Ladies;