const Kids=()=>{
    return(
        <h2>kids section</h2>
    )
}
export default Kids;