// import { useState } from "react"

// const SignUp = ()=>{
//      const [registerUser,setRegisterUser] =useState({
//         fullName:'',
//         age:'',
//         gender:'',
//         hobbies:[],
//         mobileNo:'',
//         emailId:''
//      });
//      const handleRegisterForm = e =>{
//         e.preventDefault();
//         alert("Registration form is submitted");
//      }
//     return(
//         <div className="container d-flex gap-3 rounded m-3 p-3 w-76 text-bg-secondary mx-auto">
//             <div>
//                 <h2>Registration form</h2>
//             </div>
//             <div>
//                  <form onSubmit={handleRegisterForm}>
//                     <div className="form-control" >
//                         <input placeholder="enter Your Name" type="text" required 
//                         value={registerUser.fullName}
//                         onChange={e=>setRegisterUser({...registerUser,fullName:e.target.value})}/>
//                     </div>
//                     <div>
//                         <input className="form-control" placeholder="enter Your age" type="number" required
//                         value={registerUser.age}
//                         onChange={e=>setRegisterUser({...registerUser,age:e.target.value})}
//                         required min={18} max={60}/>
//                     </div>
//                     <div className="d-flex justify-content-center">
//                         <button type="submit" className="btn btn-primary btn-outline-primary" >Submit</button>
//                         <button type="reset" className="btn btn-primary btn-warning">reset</button>
//                     </div>
//                  </form>
//             </div>
//             <div>
//                 <h3>already a user? Please Sign In</h3>
//             </div>
//         </div>
//     )
// }
// export default SignUp;
// import { useState } from "react";

// const SignUp = ({existingUser}) => {
//   const [registerUser, setRegisterUser] = useState({
//     fullName: "",
//     age: "",
//     gender: "",
//     hobbies: [],
//     mobileNo: "",
//     emailId: "",
//   });
// //   event handler function to handle checkbox change event
//  const handleHobbies = event =>{
//     const{checked,value}=event.target;
//     if(checked){
//         setRegisterUser({...registerUser,hobbies:[...registerUser.hobbies,value]})

//     }else{
//        setRegisterUser({...registerUser,hobbies:registerUser.hobbies.filter(hobby!=value)})
//     }


//  };
//   const handleRegisterForm = (e) => {
//     e.preventDefault();
//     alert("Registration form is submitted");
//   };

//   const handleReset = () => {

//     setRegisterUser({
//       fullName: "",
//       age: "",
//       gender: "",
//       hobbies: [],
//       mobileNo: "",
//       emailId: "",
//     });
//   };


//   return (
//     <div className="container d-flex gap-3 rounded m-3 p-3 w-75 text-bg-secondary mx-auto">
//       <div>
//         <h2>Registration Form</h2>
//       </div>
//       <div>
//         <form onSubmit={handleRegisterForm}>
//           <div className="form-control">
//             <input
//               name="fullName"
//               placeholder="Enter Your Name"
//               type="text"
//               required
//               value={registerUser.fullName}
//               onChange={(e) =>
//                 setRegisterUser({ ...registerUser, fullName: e.target.value })
//               }
//             />
//           </div>
//           <div>
//             <input
//               name="age"
//               className="form-control"
//               placeholder="Enter Your Age"
//               type="number"
//               required
//               value={registerUser.age}
//               onChange={(e) =>
//                 setRegisterUser({ ...registerUser, age: e.target.value })
//               }
//               min={18}
//               max={60}
//             />
//           </div>
//           <div className="mb-3 d-flex gap-2" >
//             <lable className="form-label">Select gender:</lable>
//             <div className="form-check">
//                 <input className="form-check-input"
//                 id="g1" type="radio" value="Male"
//                 checked={registerUser.gender=="Male"}
//                 onChange={e=>setRegisterUser({...registerUser,gender:e.target.value})}/>
//                 <lable className="form-check-lable" htmlFor="g1">Male</lable>
//             </div>
//             <div className="form-check">
//                 <input className="form-check-input"
//                 id="g2" type="radio" value="Male"
//                 checked={registerUser.gender=="Male"}
//                 onChange={e=>setRegisterUser({...registerUser,gender:e.target.value})}/>
//                 <lable className="form-check-lable" htmlFor="g2">Female</lable>
//             </div>
//           </div>
//           <div className="mb-3 d-flex">
//                <lable className="form-lable1">Select Your Hobbies</lable>
//                <div className="form-check">
//                   <input className="form-check-input" id="hb1" type="checkbox" value="Singint" checked={hobbies.includes("Singing")} onChange={handleHobbies}/>
//                   <lable className="form-check-label" htmlFor="hbi">Singing</lable>
//                </div>
//           </div>
//           <div className="d-flex justify-content-center mt-3">
//             <button type="submit" className="btn btn-primary me-2">
//               Submit
//             </button>
//             <button
//               type="button"
//               className="btn btn-warning"
//               onClick={handleReset}
//             >
//               Reset
//             </button>
//           </div>
//         </form>
//       </div>
//       <div>
//         <h3>Already a user? Please <button onClick={()=>existingUser(true)}>Sign In</button></h3>
//       </div>
//     </div>
//   );
// };

// export default SignUp;
import { useState } from "react";
import RegisterUserDetails from "./RegisterUserDetails"; // Import the component

const SignUp = ({ existingUser }) => {
  const [registerUser, setRegisterUser] = useState({
    fullName: "",
    age: "",
    gender: "",
    hobbies: [],
    mobileNo: "",
    emailId: "",
  });

  const [isSubmitted, setIsSubmitted] = useState(false); // Fixed useState

  const handleHobbies = (event) => {
    const { checked, value } = event.target;
    setRegisterUser((prevState) => ({
      ...prevState,
      hobbies: checked
        ? [...prevState.hobbies, value]
        : prevState.hobbies.filter((hobby) => hobby !== value),
    }));
  };

  const handleRegisterForm = (e) => {
    e.preventDefault();
    setIsSubmitted(true); // Show user details after submission
  };

  const handleReset = () => {
    setRegisterUser({
      fullName: "",
      age: "",
      gender: "",
      hobbies: [],
      mobileNo: "",
      emailId: "",
    });
    setIsSubmitted(false);
  };

  return (
    <>
      {!isSubmitted ? (
        <div className="container d-flex gap-3 rounded m-3 p-3 w-75 text-bg-secondary mx-auto">
          <div>
            <h2>Registration Form</h2>
          </div>
          <div>
            <form onSubmit={handleRegisterForm}>
              <div className="form-control">
                <input
                  name="fullName"
                  placeholder="Enter Your Name"
                  type="text"
                  required
                  value={registerUser.fullName}
                  onChange={(e) =>
                    setRegisterUser({ ...registerUser, fullName: e.target.value })
                  }
                />
              </div>
              <div>
                <input
                  name="age"
                  className="form-control"
                  placeholder="Enter Your Age"
                  type="number"
                  required
                  value={registerUser.age}
                  onChange={(e) =>
                    setRegisterUser({ ...registerUser, age: e.target.value })
                  }
                  min={18}
                  max={60}
                />
              </div>

              {/* Gender Selection */}
              <div className="mb-3 d-flex gap-2">
                <label className="form-label">Select Gender:</label>
                <div className="form-check">
                  <input
                    className="form-check-input"
                    id="g1"
                    type="radio"
                    value="Male"
                    checked={registerUser.gender === "Male"}
                    onChange={(e) =>
                      setRegisterUser({ ...registerUser, gender: e.target.value })
                    }
                  />
                  <label className="form-check-label" htmlFor="g1">
                    Male
                  </label>
                </div>
                <div className="form-check">
                  <input
                    className="form-check-input"
                    id="g2"
                    type="radio"
                    value="Female"
                    checked={registerUser.gender === "Female"}
                    onChange={(e) =>
                      setRegisterUser({ ...registerUser, gender: e.target.value })
                    }
                  />
                  <label className="form-check-label" htmlFor="g2">
                    Female
                  </label>
                </div>
              </div>

              {/* Hobbies Selection */}
              <div className="mb-3">
                <label className="form-label">Select Your Hobbies:</label>
                <div className="form-check">
                  <input
                    className="form-check-input"
                    id="hb1"
                    type="checkbox"
                    value="Singing"
                    checked={registerUser.hobbies.includes("Singing")}
                    onChange={handleHobbies}
                  />
                  <label className="form-check-label" htmlFor="hb1">
                    Singing
                  </label>
                </div>
                <div className="form-check">
                  <input
                    className="form-check-input"
                    id="hb2"
                    type="checkbox"
                    value="Dancing"
                    checked={registerUser.hobbies.includes("Dancing")}
                    onChange={handleHobbies}
                  />
                  <label className="form-check-label" htmlFor="hb2">
                    Dancing
                  </label>
                </div>
                <div className="form-check">
                  <input
                    className="form-check-input"
                    id="hb3"
                    type="checkbox"
                    value="Reading"
                    checked={registerUser.hobbies.includes("Reading")}
                    onChange={handleHobbies}
                  />
                  <label className="form-check-label" htmlFor="hb3">
                    Reading
                  </label>
                </div>
              </div>

              {/* Mobile Number */}
              <div className="mb-3">
                <input
                  className="form-control"
                  placeholder="10 digits mobile number"
                  type="tel"
                  value={registerUser.mobileNo}
                  onChange={(e) =>
                    setRegisterUser({ ...registerUser, mobileNo: e.target.value })
                  }
                  required
                  pattern="[0-9]{10}"
                />
              </div>

              {/* Email ID */}
              <div className="mb-3">
                <input
                  className="form-control"
                  placeholder="Enter email ID"
                  type="email"
                  value={registerUser.emailId}
                  onChange={(e) =>
                    setRegisterUser({ ...registerUser, emailId: e.target.value })
                  }
                  required
                />
              </div>

              {/* Submit & Reset Buttons */}
              <div className="d-flex justify-content-center mt-3">
                <button type="submit" className="btn btn-primary me-2">
                  Submit
                </button>
                <button type="button" className="btn btn-warning" onClick={handleReset}>
                  Reset
                </button>
              </div>
            </form>
          </div>

          {/* Sign In Prompt */}
          <div>
            <h3>
              Already a user? Please <button onClick={() => existingUser(true)}>Sign In</button>
            </h3>
          </div>
        </div>
      ) : (
        <RegisterUserDetails newUser={registerUser} />
      )}
    </>
  );
};

export default SignUp;

